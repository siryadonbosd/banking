package com.cg.banking.util;

public class DBUtilException extends Exception {

	public DBUtilException(String errorMsg) {
		super(errorMsg);
	}

	
	


}
